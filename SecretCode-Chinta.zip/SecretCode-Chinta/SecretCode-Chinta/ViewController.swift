//
//  ViewController.swift
//  SecretCode-Chinta
//
//  Created by Raja Srikar Karthik Chinta on 2/28/18.
//  Copyright © 2018 Raja Srikar Karthik Chinta. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print(AppDelegate.codeModel.Count)
        return AppDelegate.codeModel.Count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "symbol")
        cell?.textLabel?.text = AppDelegate.codeModel.Symbols[indexPath.row]
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        AppDelegate.codeModel.addSymbol(sym: AppDelegate.codeModel.Symbols[indexPath.row])
        GuessLBL.text="The Guess \(AppDelegate.codeModel.currentGuess())"
        StatusLBL.text=AppDelegate.codeModel.statusOfGuess()
    }
    @IBOutlet weak var GuessLBL: UILabel!
    @IBOutlet weak var StatusLBL: UILabel!
    
}

