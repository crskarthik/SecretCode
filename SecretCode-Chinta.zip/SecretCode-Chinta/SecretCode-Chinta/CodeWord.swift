//
//  CodeWord.swift
//  SecretCode-Chinta
//
//  Created by Raja Srikar Karthik Chinta on 2/28/18.
//  Copyright © 2018 Raja Srikar Karthik Chinta. All rights reserved.
//

import UIKit

class CodeWord: NSObject {
    var Symbols:[String]=[]
    var Count:Int=0
    var Code:[String]=[]
    var Guess:[String]=[]
    var OnSymbol:Int=0
    var Attempts:Int
    var Status:String=""
    init(CodeSize n:Int)
    {
        if n>=4
        {
            Count=n
            for _ in 1...n{
                Symbols.append(String(arc4random_uniform(UInt32(10))))
                
            }
            
            //        for _ in 1...n{
            //            Code.append(Symbols[Int(arc4random_uniform(UInt32(Symbols.count)))])
            //        }
            Code = Symbols
        }
        Attempts=1
        print(Symbols)
        
    }
    
    func addSymbol(sym:String){
        
        if OnSymbol == Code.count
        {
            OnSymbol = 0
            Status = "Guess Complete \(noOfCorrectPositions()) Correct \nHint : Sum of difference in digits \(sumOfDifferences())"
            if isMatched()
            {
                Code.append(Symbols[0])
            }
        }
        else{
            Guess.append(sym)
            OnSymbol += 1
            Status = "Attempt \(Attempts): \(Guess.count) guessed"
        }
        
    }
    func noOfCorrectPositions()->Int{
        var crt:Int = 0
        for i in 0..<Count{
            if Guess[i] == Code[i]
            {
                crt += 1
            }
        }
        return crt
    }
    func statusOfGuess()->String{
        return Status
    }
    func currentGuess()->[String]
    {
        return Guess
    }
    func isMatched()->Bool
    {
        var t=0
        for i in 0..<Count{
            if Guess[i] == Code[i]
            {
                t=1
            }
            else{
                t=0
                break
            }
        }
        return t == 1
    }
    func sumOfDifferences()->Int{
        var sum:Int=0
        for i in 0..<Count
        {
            sum += Int(Code[i])! - Int(Guess[i])!
        }
        return sum
    }
    func reset()
    {
        OnSymbol = 0
        Code=[]
        Guess=[]
        
        for _ in 1...Symbols.count{
            Code.append(Symbols[Int(arc4random_uniform(UInt32(Symbols.count)))])
        }
        Count=0
    }
}
