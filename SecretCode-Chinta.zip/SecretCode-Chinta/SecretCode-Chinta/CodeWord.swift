//
//  CodeWord.swift
//  SecretCode-Chinta
//
//  Created by Raja Srikar Karthik Chinta on 2/28/18.
//  Copyright © 2018 Raja Srikar Karthik Chinta. All rights reserved.
//

import UIKit

class CodeWord: NSObject {
    var Symbols:[String]=[]
    var Count:Int=0
    var Code:[String]=[]
    var Guess:[String]=[]
    var OnSymbol:Int=0
    var Attempts:Int
    var Status:String=""
    init(CodeSize n:Int)
    {
        if n>=4
        {
            Count=n
            Symbols = ["A","B","C","D","అ","ஜ"]
            for _ in 1...Count{
                Code.append(Symbols[Int(arc4random_uniform(UInt32(Symbols.count)))])
            }
            
        }
        Attempts=1
        print(Symbols)
        print(Code)
        
    }
    
    func addSymbol(sym:String){
        
        if OnSymbol == Code.count && OnSymbol == Guess.count
        {
            OnSymbol = 0
            Status = "Guess Complete \(noOfCorrectPositions())"
            if isMatched()
            {
                Code.append(Symbols[Int(arc4random_uniform(UInt32(Symbols.count)))])
                print("New Code: \(Code)")
            }
        }
        else if OnSymbol < Code.count{
            Guess.append(sym)
            OnSymbol += 1
            Status = "Attempt \(Attempts): \(Guess.count) guessed"
        }
        print(Guess)
    }
    func noOfCorrectPositions()->Int{
        var crt:Int = 0
        for i in 0..<Count{
            if Guess[i] == Code[i]
            {
                crt += 1
            }
        }
        return crt
    }
    func statusOfGuess()->String{
        return Status
    }
    func currentGuess()->[String]
    {
        return Guess
    }
    func isMatched()->Bool
    {
        var t=0
        for i in 0..<Count{
            if Guess[i] == Code[i]
            {
                t=1
            }
            else{
                t=0
                break
            }
        }
        return t == 1
    }
//    func sumOfDifferences()->Int{
//        var sum:Int=0
//        for i in 0..<Count
//        {
//            sum += Int(Code[i])! - Int(Guess[i])!
//        }
//        return sum
//    }
    func reset()
    {
        OnSymbol = 0
        Code=[]
        Guess=[]
        
        for _ in 1...Count{
            Code.append(Symbols[Int(arc4random_uniform(UInt32(Symbols.count)))])
        }
        Count=0
    }
}
